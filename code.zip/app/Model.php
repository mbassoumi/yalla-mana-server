<?php
/**
 * Created by PhpStorm.
 * User: majd2
 * Date: 2017-08-04
 * Time: 9:44 PM
 */

namespace App;
use Illuminate\Database\Eloquent\Model as Eloquent;

class Model extends Eloquent
{
    protected $guarded =[];
}